    //You can change only 2 characters
    let i = 3;
    while (i) {
    console.log( i-- );
    }