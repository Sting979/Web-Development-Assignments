let gifts = ["teddy bear", "drone", "doll"];

for (let i = 0; i < 3; i++) {
  console.log(`Wrapped ${gifts[i]} and added a bow!`);
}