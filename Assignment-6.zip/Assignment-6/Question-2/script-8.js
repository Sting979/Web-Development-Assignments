let message;
let lock = 2;
//Dont change any code below this 
if (null || undefined )
{
  message = "Go away";
}
else
{
 message = "welcome";
}
console.log(message);