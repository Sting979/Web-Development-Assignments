let a = prompt("First number?");
let b = prompt("Second number?");
c=parseInt(a)+parseInt(b)
alert(c)