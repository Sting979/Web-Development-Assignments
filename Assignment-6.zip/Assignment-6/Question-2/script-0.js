alert("I'm JavaScript!");
alert("Hello") // this line is not having semicolon
alert(`Wor
 ld`)
alert(3 +
1 
+ 2); // this is multiple line code and its working