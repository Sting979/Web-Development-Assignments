var lemein = "0"; //true
var lemeout = 0; //false
var msg = "";
if (lemein) { //executed
 msg += "hi";
 }
if (lemeout) {//Not executed
 msg += 'Hello';
}
console.log(msg);