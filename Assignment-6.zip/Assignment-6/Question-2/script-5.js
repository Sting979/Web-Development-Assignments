let a = parseInt(prompt("Enter a number?"));
//Don't modify any code below this
if (a) {
console.log( 'OMG it works for any number inc 0' );
}
else
{
 console.log( "Success" );
}
