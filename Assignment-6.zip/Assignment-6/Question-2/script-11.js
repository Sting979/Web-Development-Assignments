let num = 1
process.stdout.write(num+" ")
num += 1
process.stdout.write(num+" ")
num += 1
console.log(num)
num += 1
process.stdout.write(num+" ")
num += 1
process.stdout.write(num+" ")
num += 1
console.log(num)
num += 1
process.stdout.write(num+" ")
num += 1
process.stdout.write(num+" ")
num += 1
console.log(num)
num += 1
console.log(num)