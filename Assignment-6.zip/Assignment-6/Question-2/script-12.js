//You are allowed to modify only one character 
for (let num = 2; num <= 20; num += 2) {
    console.log(num)
  }